package Programación.UD4;

public class Ej1 {
    public static void main(String[] args) {
        int diaseEnunAño = 365;
        int horas = diaseEnunAño * 24;
        int minutos = horas * 60;
        int segundos = minutos * 60;

        System.out.println("En un año hay:");
        System.out.println("horas " + horas);
        System.out.println("minutos " + minutos);
        System.out.println("segundos " + segundos);

    }
}
