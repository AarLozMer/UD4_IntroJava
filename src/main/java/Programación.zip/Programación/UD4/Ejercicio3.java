package Programación.UD4;

public class Ejercicio3 {
    public static void main(String[] args) {
        int j = -2;
        boolean b = (j > 0) && (1/(j+2) > 10);
        System.out.println("La variable B tiene un valor de " + b);

    }
}
